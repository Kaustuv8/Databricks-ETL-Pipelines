# Databricks notebook source
from pyspark.sql.functions import base64, aes_encrypt, aes_decrypt, lit, col
from pyspark.sql.dataframe import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, IntegerType

class Encrypter():
    key = "0123456789abcdef0123456789abcdef"
    
    def encrypt(self, column: str):
        return aes_encrypt(
            col(column).cast("STRING"),
            lit(self.key),
            lit("GCM")
        )
    def decrypt_to_string(self, column: str):
        return aes_decrypt(
            col(column),
            lit(self.key),
            lit("GCM")
        ).cast("STRING")



    
    def encrypt_columns(self, df: DataFrame, *columns):
        for column in columns:
            df = df.withColumn(
                column,
                self.encrypt(column)
            )
        return df
    
    def decrypt_columns(self, df: DataFrame, *columns, convert_to_int = False):
        print(columns)
        for column in columns:
            dtype = df.schema[column].dataType
           # print(dtype)
            df = df.withColumn(column, self.decrypt_to_string(column))
            
        return df